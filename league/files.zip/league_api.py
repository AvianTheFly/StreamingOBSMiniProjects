# league/league_api.py

import threading

import requests
import urllib3

from .config import (
    LEAGUE_API_URL,
    POLL_INTERVAL,
    DISCONNECTED_INTERVAL,
    REQUEST_TIMEOUT,
)
from .league_events import LeagueEvents
from .game_state_detector import GameStateDetector

# ── Existing handlers ─────────────────────────────────────────────────────────
from .death_handler           import make_death_handler
from .respawn_handler         import make_respawn_handler
from .game_end_handler        import make_game_end_handler
from .recall_complete_handler import make_recall_complete_handler
from .level_up_handler        import make_level_up_handler

# ── New event-feed handlers ───────────────────────────────────────────────────
from .game_start_handler        import make_game_start_handler
from .minions_spawning_handler  import make_minions_spawning_handler
from .first_brick_handler       import make_first_brick_handler
from .turret_killed_handler     import make_turret_killed_handler
from .inhib_killed_handler      import make_inhib_killed_handler
from .dragon_kill_handler       import make_dragon_kill_handler
from .herald_kill_handler       import make_herald_kill_handler
from .baron_kill_handler        import make_baron_kill_handler
from .champion_kill_handler     import make_champion_kill_handler
from .multikill_handler         import make_multikill_handler
from .ace_handler               import make_ace_handler

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class LeagueAPIWatcher:
    def __init__(self, stop_event: threading.Event):
        self.stop_event = stop_event

        self.events = LeagueEvents()

        # ── State-diff events ─────────────────────────────────────────────
        self.events.register("death",           make_death_handler())
        self.events.register("respawn",         make_respawn_handler())
        self.events.register("game_end",        make_game_end_handler())
        self.events.register("recall_complete", make_recall_complete_handler())
        self.events.register("level_changed",   make_level_up_handler())

        # ── Event-feed events ─────────────────────────────────────────────
        # Toggle ENABLED flags and set scene/source names in config.py.
        self.events.register("game_start",       make_game_start_handler())
        self.events.register("minions_spawning", make_minions_spawning_handler())
        self.events.register("first_brick",      make_first_brick_handler())
        self.events.register("turret_killed",    make_turret_killed_handler())
        self.events.register("inhib_killed",     make_inhib_killed_handler())
        self.events.register("dragon_kill",      make_dragon_kill_handler())
        self.events.register("herald_kill",      make_herald_kill_handler())
        self.events.register("baron_kill",       make_baron_kill_handler())
        self.events.register("champion_kill",    make_champion_kill_handler())
        self.events.register("multikill",        make_multikill_handler())
        self.events.register("ace",              make_ace_handler())

        self.detector       = GameStateDetector(self.events)
        self.game_connected = False

        self._last_resource_value: float = 0.0
        self._last_active: dict          = {}

    # ── Public: called from the keyboard listener in main.py ──────────────────

    def on_recall_key(self) -> None:
        if not self.game_connected:
            return
        self.detector.start_recall_watch(self._last_resource_value, self._last_active)

    # ── Main poll loop ────────────────────────────────────────────────────────

    def run(self) -> None:
        print("[league] Watcher started — waiting for a game.")

        while not self.stop_event.is_set():
            try:
                data = self._fetch()
                me   = self._find_active_player(data)

                if me is None:
                    print("[league] Active player not found in game data.")
                    self.stop_event.wait(DISCONNECTED_INTERVAL)
                    continue

                active = data.get("activePlayer", {})
                self._last_active         = active
                self._last_resource_value = (
                    active.get("championStats", {}).get("resourceValue", 0.0)
                )

                self._on_connected()
                self.detector.process(me, data)
                self.stop_event.wait(POLL_INTERVAL)

            except requests.exceptions.ConnectionError:
                self._on_disconnected()
                self.stop_event.wait(DISCONNECTED_INTERVAL)

            except Exception as e:
                print(f"[league] Unexpected error: {e}")
                self.stop_event.wait(DISCONNECTED_INTERVAL)

        print("[league] Stopped.")

    # ── Private ───────────────────────────────────────────────────────────────

    def _fetch(self) -> dict:
        resp = requests.get(LEAGUE_API_URL, verify=False, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def _on_connected(self) -> None:
        if not self.game_connected:
            self.game_connected = True
            print("[league] Game detected — tracking started.")
            self.events.emit("game_start")

    def _on_disconnected(self) -> None:
        if self.game_connected:
            self.game_connected = False
            self.detector.reset()
            print("[league] Game ended or client closed.")
            self.events.emit("game_end")

    def _find_active_player(self, data: dict):
        active_name = (
            data.get("activePlayer", {})
                .get("summonerName", "")
                .strip()
                .lower()
        )
        if not active_name:
            return None

        for player in data.get("allPlayers", []):
            if player.get("summonerName", "").strip().lower() == active_name:
                return player

        return None
