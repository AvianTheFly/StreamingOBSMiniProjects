# league/game_start_handler.py
# Triggered once when the API first becomes reachable (game detected).

import threading
import obs
from .config import (
    GAME_START_SCENE, GAME_START_SOURCE,
    GAME_START_DURATION, GAME_START_ENABLED,
)


def make_game_start_handler():
    def handle_game_start():
        if not GAME_START_ENABLED:
            return
        print("[league] Game start detected.")
        try:
            if GAME_START_DURATION is None:
                obs.show_source(GAME_START_SCENE, GAME_START_SOURCE)
            else:
                threading.Thread(
                    target=obs.toggle_source,
                    args=(GAME_START_SCENE, GAME_START_SOURCE, GAME_START_DURATION),
                    daemon=True,
                ).start()
        except Exception as e:
            print(f"[league] Game start handler error: {e}")

    return handle_game_start
