# league/champion_kill_handler.py
# Triggered when the local player kills an enemy champion.
# (Filtering by KillerName == active player is done in game_state_detector.)
#
# event fields: { EventName, EventTime, VictimName, KillerName, Assisters[] }

import threading
import obs
from .config import (
    CHAMPION_KILL_SCENE, CHAMPION_KILL_SOURCE,
    CHAMPION_KILL_DURATION, CHAMPION_KILL_ENABLED,
)


def make_champion_kill_handler():
    def handle_champion_kill(event: dict):
        if not CHAMPION_KILL_ENABLED:
            return
        victim = event.get("VictimName", "unknown")
        print(f"[league] You killed {victim}!")
        try:
            if CHAMPION_KILL_DURATION is None:
                obs.show_source(CHAMPION_KILL_SCENE, CHAMPION_KILL_SOURCE)
            else:
                threading.Thread(
                    target=obs.toggle_source,
                    args=(CHAMPION_KILL_SCENE, CHAMPION_KILL_SOURCE, CHAMPION_KILL_DURATION),
                    daemon=True,
                ).start()
        except Exception as e:
            print(f"[league] Champion kill handler error: {e}")

    return handle_champion_kill
